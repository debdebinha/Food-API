// O código começa importando os módulos necessários do Mongoose, que é uma biblioteca do Node.js para modelagem de dados e interação com o MongoDB
import {model, Schema } from 'mongoose';

export const Category = model('Category', new Schema({ // A constante Category é criada usando o método model do Mongoose. Isso define um modelo de dados para uma categoria.
	name: { // campo obrigatório. cada documento da categoria deve ter um valor não vazio para o campo name.
		type: String,
		required: true,
	},
	icon: { // campo obrigatório. armazena informações sobre o ícone associado à categoria
		type: String,
		required: true,
	}
}));