// o código começa importando os módulos Request e Response do Express. Esses módulos são usados para lidar com objetos de solicitação HTTP (Request) e objetos de resposta HTTP (Response).
import { Request, Response } from 'express';
import { Category } from '../../models/Category';

export async function listCategories(req: Request, res: Response) { // controlador responsável por buscar e listar todas as categorias quando uma solicitação GET é feita para a rota associada a esta função.
	// a função é definida dentro de um bloco try-catch para lidar com erros potenciais que possam ocorrer durante o processo de listagem das categorias;
	try {
		const categories = await Category.find(); // realiza uma consulta ao banco de dados MongoDB usando o método find() do modelo Category. Isso busca todas as categorias existentes no banco de dados e armazena-as na variável categories.

		res.json(categories); // se a consulta for bem-sucedida, a função responde com um status HTTP 200 (OK) e envia a lista de categorias como uma resposta JSON
	} catch (error) { // se ocorrer algum erro durante o processo de consulta das categorias, ele é capturado pelo bloco catch.
		console.log(error); // o erro é registrado no console
		res.sendStatus(500); // função responde com um status HTTP 500 (Internal Server Error)
	}
}