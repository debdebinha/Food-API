// O código começa importando os módulos Request e Response do Express. Esses módulos são usados para lidar com objetos de solicitação HTTP (Request) e objetos de resposta HTTP (Response).
import { Request, Response } from 'express';
import { Order } from '../../models/Order';

export async function createOrder(req: Request, res: Response) { // responsável por criar um novo pedido quando uma solicitação POST é feita para a rota associada a esta função.
	// A função é definida dentro de um bloco try-catch para lidar com erros potenciais que possam ocorrer durante o processo de criação do pedido.
	try {
		const {table, products} = req.body; // criando o novo pedido

		const order = await Order.create({ table, products }); // Os valores table e products extraídos da solicitação são passados como argumentos para criar um novo pedido no banco de dados. A palavra-chave await é usada para aguardar que a operação de criação seja concluída antes de prosseguir.
		res.status(201).json(order); // Se o pedido for criado com sucesso, a função responde com um status HTTP 201 (Created) e envia o pedido criado como uma resposta JSON 
	} catch (error) { // Se ocorrer algum erro durante o processo de criação do pedido, ele é capturado pelo bloco catch.
		console.log(error); // O erro é registrado no console 
		res.sendStatus(500); //  função responde com um status HTTP 500 (Internal Server Error)
	}
}